<?php

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Slim\Factory\AppFactory;

require __DIR__ . '/vendor/autoload.php';

$app = AppFactory::create();

// Verbindung zur Datenbank
$db = new PDO('mysql:host=localhost;dbname=id21243083_internetx', 'id21243083_maxtrustworth', 'DonMassa666#');

// POST /user Route
$app->post('/user', function (Request $request, Response $response) use ($db) {
    $data = $request->getParsedBody();
    $hashedPassword = password_hash($data['password'], PASSWORD_DEFAULT);
    $stmt = $db->prepare("INSERT INTO users (email, fname, lname, password, admin) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$data['email'], $data['fname'], $data['lname'], $hashedPassword, $data['admin']]);
    return $response->withStatus(201);
});

// Weitere Routen (GET /user/$email und DELETE /user/$email) können hier hinzugefügt werden...

$app->run();

